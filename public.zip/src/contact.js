import React from 'react';


import { BrowserRouter as Router, Route} from "react-router-dom";
import About from './about';


function Contact() {
  return (
    <div className="App">
     <h1>Conatct Us</h1>
    </div>
  );
}

export default Contact;