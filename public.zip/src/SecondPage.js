import React from 'react';
import { CircularProgressbar, buildStyles  } from 'react-circular-progressbar';
import ChangingProgressProvider from "./ChangingProgressProvider";
import './new.css';
const percentage1 = 80;
const percentage = 40;

class SecondPage extends React.Component{
    render() {
      return (
        <div className="container-fluid space">
        <div className="row">
          <div className="col-md-6 col-sm-6 col-xs-12">
            <div className="row justify-content-center">
              <div className="circle">
              <h3>SEO Result</h3>
                {/* <CircularProgressbar className="circle" value={percentage} text={`${percentage1}%`}
                                      styles={{
                                        // Customize the path, i.e. the "completed progress"
                                        path: {
                                          // Path color
                                          stroke: `rgba(62, 152, 199, ${percentage1 / 100})`,
                                          // Whether to use rounded or flat corners on the ends - can use 'butt' or 'round'
                                          strokeLinecap: 'butt',
                                          // Customize transition animation
                                          transition: 'stroke-dashoffset 0.5s ease 0s',
                                          // Rotate the path
                                          
                                          transformOrigin: 'center center',
                                        }
                                       }} /> */}
                                          <ChangingProgressProvider values={[percentage1]}>
        {percentage => (
          <CircularProgressbar value={percentage} text={`${percentage}%`} />
        )}
      </ChangingProgressProvider>
                {/* <div className="seo circle">
                  <strong></strong>
                </div> */}
              </div>
            </div>
            <div className="row justify-content-center">
              <div className="panel-group">
                  <div className="panel panel-default">
                    <div className="panel-heading">
                      <h4 className="panel-title">
                        <p data-toggle="collapse" href="#collapse1">Point 1 <i className="fas fa-angle-double-down right"></i></p>
                      </h4>
                    </div>
                    <div id="collapse1" className="panel-collapse collapse">
                      <ul className="list-group">
                        <li className="list-group-item">One</li>
                        <li className="list-group-item">Two</li>
                        <li className="list-group-item">Three</li>
                      </ul>
                    </div>
                    
                    <div className="panel-heading">
                      <h4 className="panel-title">
                        <p data-toggle="collapse" href="#collapse2">Point 2 <i className="fas fa-angle-double-down right"></i></p>
                      </h4>
                    </div>
                    <div id="collapse2" className="panel-collapse collapse">
                      <ul className="list-group">
                        <li className="list-group-item">Four</li>
                        <li className="list-group-item">Five</li>
                        <li className="list-group-item">Six</li>
                      </ul>
                    </div>
                  </div>
                </div>
            </div>
          </div>

          <div className="col-md-6 col-sm-6 col-xs-12">
            <div className="row justify-content-center">
              <div className="circle">
              <h3>AODA Result</h3>
              <ChangingProgressProvider values={[percentage]}>
        {percentage => (
          <CircularProgressbar value={percentage} text={`${percentage}%`} />
        )}
      </ChangingProgressProvider>
                {/* <div className="aoda circle">
                  <strong></strong>
                </div> */}
              </div>
            </div>
            <div className="row justify-content-center">
              <div className="panel-group">
                  <div className="panel panel-default">
                    <div className="panel-heading">
                      <h4 className="panel-title">
                        <p data-toggle="collapse" href="#collapse3">Point 3 <i className="fas fa-angle-double-down right"></i></p>
                      </h4>
                    </div>
                    <div id="collapse3" className="panel-collapse collapse">
                      <ul className="list-group">
                        <li className="list-group-item">One</li>
                        <li className="list-group-item">Two</li>
                        <li className="list-group-item">Three</li>
                      </ul>
                    </div>
                    
                    <div className="panel-heading">
                      <h4 className="panel-title">
                        <p data-toggle="collapse" href="#collapse4">Point 4 <i className="fas fa-angle-double-down right"></i></p>
                      </h4>
                    </div>
                    <div id="collapse4" className="panel-collapse collapse">
                      <ul className="list-group">
                        <li className="list-group-item">Four</li>
                        <li className="list-group-item">Five</li>
                        <li className="list-group-item">Six</li>
                      </ul>
                    </div>
                  </div>
                </div>
            </div>
          </div>
          </div>
          
    </div>

    
      
      );
      
    }
  }
  
  
  export default SecondPage;